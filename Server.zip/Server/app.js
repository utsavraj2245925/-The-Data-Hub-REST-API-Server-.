const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();

// Level 2: Mock database (in-memory)
let blogPosts = [];

// Level 3: Custom middleware (logs method, url, timestamp)
app.use((req, res, next) => {
	const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
	console.log(`[${req.method}] ${req.originalUrl} - ${time}`);
	next();
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
	res.status(200).send('OK');
});

// Level 3: Fake authentication
app.post('/login', (req, res) => {
	const { username, password } = req.body ?? {};
    console.log(username, password);
	if (!username || !password) {
		return res.status(400).json({ message: 'username and password are required' });
	}

	// Mock JWT-like string (NOT a real signed token)
	const payload = {
		sub: String(username),
		iat: Date.now(),
	};

	const base64Url = Buffer.from(JSON.stringify(payload))
		.toString('base64')
		.replace(/=/g, '')
		.replace(/\+/g, '-')
		.replace(/\//g, '_');

	const token = `mock-jwt.${base64Url}.signature`;

	return res.status(200).json({ token });
});

// Blog REST routes

// GET /posts - return all posts (Level 2 CRUD)
app.get('/posts', (req, res) => {
	return res.status(200).json(blogPosts);
});

// GET /posts/:id - basic route + returns post if found
app.get('/posts/:id', (req, res) => {
    const { id } = req.params;
    const post = blogPosts.find((p) => p.id === id);

    if (!post) {
        return res.status(404).json({ message: 'Post not found' });
    }
	return res.status(200).json({post, message:"Post found"});
});

// POST /posts - create a new post (Level 2 CRUD)
app.post('/posts', (req, res) => {
	const data = req.body ?? {};

	const id = typeof crypto.randomUUID === 'function'
		? crypto.randomUUID()
		: String(Date.now());

	const newPost = {
		id,
		...data,
		createdAt: new Date().toISOString(),
	};

	blogPosts.push(newPost);
	return res.status(201).json(newPost);
});

// PUT /posts/:id - update a post
app.put('/posts/:id', (req, res) => {
    const { id } = req.params;
    const index = blogPosts.findIndex((p) => p.id === id);

    if (index === -1) {
        return res.status(404).json({ message: 'Post not found' });
    }

    const updatedPost = { ...blogPosts[index], ...req.body };
    blogPosts[index] = updatedPost;

    return res.status(200).json({ post: updatedPost, message: 'Post updated' });
});

// DELETE /posts/:id - delete by id (Level 2 CRUD)
app.delete('/posts/:id', (req, res) => {
	const { id } = req.params;
	const index = blogPosts.findIndex((p) => p.id === id);

	if (index === -1) {
		return res.status(404).json({ message: 'Post not found' });
	}

	const deleted = blogPosts.splice(index, 1)[0];
	return res.status(200).json({ message: 'Deleted', deleted });
});

const PORT = Number(process.env.PORT) || 3000;

app.listen(PORT, () => {
	console.log(`Server listening on port ${PORT}`);
});

