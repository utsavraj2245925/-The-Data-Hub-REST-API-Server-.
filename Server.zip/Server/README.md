# Server (Express) — Blog Posts API

A small Express server that exposes a REST API for blog posts using an in-memory array (mock database). Data resets whenever the server restarts.

## Requirements

- Node.js (any recent LTS should work)

## Install

```bash
npm install
```

## Run

```bash
# production
npm run start

# development (auto-reload)
npm run dev
```

The server listens on:

- `http://localhost:3000` by default
- or `http://localhost:<PORT>` if you set `PORT`

Example:

```bash
$env:PORT=4000
npm run start
```

## Architecture

### High-level flow

1. **Express app** receives an HTTP request.
2. **Custom logging middleware** logs method + URL + timestamp.
3. **CORS** is enabled for cross-origin requests.
4. **Body parsing** is enabled (`express.json()` + `express.urlencoded()`).
5. **Route handlers** read/write `blogPosts` (an in-memory array).

### Key components

- **In-memory data store**: `blogPosts` is a plain array kept in server memory.
    - Pros: simple and fast for demos
    - Cons: not persistent; restarting the server clears all posts

- **ID generation**: on `POST /posts`, the server generates an `id` using `crypto.randomUUID()` (or `Date.now()` as a fallback).

- **Authentication**: `POST /login` returns a *mock* JWT-like token string.
    - This token is **not signed** and is **not validated** by any route.
    - The `/posts` routes currently do **not** require authentication.

## API

### Health

- `GET /` → returns `OK`

### Auth (mock)

- `POST /login`
    - Body: `{ "username": "...", "password": "..." }`
    - Response: `{ "token": "mock-jwt.<payload>.signature" }`

### Posts (CRUD)

- `GET /posts` → returns all posts
- `GET /posts/:id` → returns `{ post, message }` or `404`
- `POST /posts` → creates a post and returns it (`201`)
- `PUT /posts/:id` → updates a post and returns `{ post, message }` or `404`
- `DELETE /posts/:id` → deletes a post and returns `{ message, deleted }` or `404`

#### Post object shape

There is no strict schema validation: the server stores whatever JSON you send.

On create, the server will always add:

- `id` (string)
- `createdAt` (ISO string)

Example created post:

```json
{
    "id": "2e5b3d4a-6a9f-4c2d-9c59-5a1f56d0f6f1",
    "title": "Hello",
    "content": "My first post",
    "createdAt": "2026-03-12T12:34:56.789Z"
}
```

## Using Postman (Posts)

Assume the server is running at `http://localhost:3000`.

Tip: In Postman, you can create an environment variable:

- `baseUrl` = `http://localhost:3000`

Then use `{{baseUrl}}/posts` in requests.

### 1) GET all posts

- **Method**: `GET`
- **URL**: `{{baseUrl}}/posts`
- **Body**: none
- **Expected response**: `200 OK` with `[]` or an array of posts

### 2) POST (create) a post

- **Method**: `POST`
- **URL**: `{{baseUrl}}/posts`
- **Headers**: `Content-Type: application/json`
- **Body**: Body tab → `raw` → `JSON`

Example body:

```json
{
    "title": "Post title",
    "content": "Post content"
}
```

- **Expected response**: `201 Created`
    - Copy the `id` from the response; you’ll use it for PUT/DELETE and GET by id.

### 3) GET a single post by id

- **Method**: `GET`
- **URL**: `{{baseUrl}}/posts/<id>`

Example:

- `{{baseUrl}}/posts/2e5b3d4a-6a9f-4c2d-9c59-5a1f56d0f6f1`

- **Expected response**:
    - `200 OK` with `{ "post": { ... }, "message": "Post found" }`
    - or `404 Not Found` with `{ "message": "Post not found" }`

### 4) PUT (update) a post

- **Method**: `PUT`
- **URL**: `{{baseUrl}}/posts/<id>`
- **Headers**: `Content-Type: application/json`
- **Body**: Body tab → `raw` → `JSON`

Example body (partial updates are allowed because the server merges fields):

```json
{
    "title": "Updated title"
}
```

- **Expected response**: `200 OK` with:

```json
{
    "post": { "...": "..." },
    "message": "Post updated"
}
```

### 5) DELETE a post

- **Method**: `DELETE`
- **URL**: `{{baseUrl}}/posts/<id>`
- **Body**: none

- **Expected response**: `200 OK` with:

```json
{
    "message": "Deleted",
    "deleted": { "...": "..." }
}
```

## Notes

- Requests are logged to the console like: `[GET] /posts - 10:42 AM`.
- Since storage is in-memory, restarting the server clears `blogPosts`.
